from unittest import TestCase, main

from project.vehicle import Vehicle


class VehicleTests(TestCase):
    def test_vehicle_init(self):
        vehicle = Vehicle(100, 150)

        self.assertEqual(100, vehicle.fuel)
        self.assertEqual(100, vehicle.capacity)
        self.assertEqual(150, vehicle.horse_power)
        self.assertEqual(1.25, Vehicle.DEFAULT_FUEL_CONSUMPTION)

    def test_str_return_proper_str(self):
        vehicle = Vehicle(100, 150)
        expected = f"The vehicle has 150 " \
                   f"horse power with 100 fuel left and 1.25 fuel consumption"
        self.assertEqual(expected, str(vehicle))

    def test_drive_raises_when_destination_not_reachable(self):
        vehicle = Vehicle(100, 150)
        with self.assertRaises(Exception) as details:
            vehicle.drive(120)
        self.assertEqual('Not enough fuel', str(details.exception))

    def test_drive_reduces_fuel_when_destination_reachable(self):
        vehicle = Vehicle(100, 150)
        vehicle.drive(10)
        expected = 100 - (vehicle.fuel_consumption * 10)
        self.assertEqual(expected, vehicle.fuel)

    def test_drive_raises_when_tank_is_full(self):
        vehicle = Vehicle(100, 150)
        with self.assertRaises(Exception) as details:
            vehicle.refuel(11)
        self.assertEqual('Too much fuel', str(details.exception))

    def test_refuel_increase_fuel_when_given_fuel_is_valid(self):
        vehicle = Vehicle(100, 150)
        vehicle.fuel = 50
        vehicle.refuel(50)
        self.assertEqual(100, vehicle.fuel)


if __name__ == '__main__':
    main()
