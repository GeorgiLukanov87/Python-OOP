from unittest import TestCase, main

from project.hero import Hero


class HeroTests(TestCase):
    USERNAME = 'Gosho'
    LEVEL = 5
    HEALTH = 100
    DAMAGE = 50

    def setUp(self) -> None:
        self.hero = Hero(self.USERNAME, self.LEVEL, self.HEALTH, self.DAMAGE)

    def test_init(self):
        self.assertEqual('Gosho', self.hero.username)
        self.assertEqual(5, self.hero.level)
        self.assertEqual(100, self.hero.health)
        self.assertEqual(50, self.hero.damage)

    def test_str(self):
        result = f"Hero Gosho: 5 lvl\n" \
                 f"Health: 100\n" \
                 f"Damage: 50\n"

        self.assertEqual(result, self.hero.__str__())

    def test_battle_raises_if_wrong_enemy_name(self):
        enemy_hero = Hero('Gosho', 5, 100, 50)
        with self.assertRaises(Exception) as ex:
            self.hero.battle(enemy_hero)
        self.assertEqual("You cannot fight yourself", str(ex.exception))

    def test_battle_raises_if_health_is_0(self):
        enemy_hero = Hero('enemy', 5, 100, 50)
        self.hero.health = 0
        with self.assertRaises(ValueError) as error:
            self.hero.battle(enemy_hero)
        self.assertEqual("Your health is lower than or equal to 0. You need to rest", str(error.exception))

    def test_battle_raises_if_health_is_negative(self):
        enemy_hero = Hero('enemy', 5, 100, 50)
        self.hero.health = -50
        with self.assertRaises(ValueError) as error:
            self.hero.battle(enemy_hero)
        self.assertEqual("Your health is lower than or equal to 0. You need to rest", str(error.exception))

    def test_battle_raises_if_enemy_health_is_0(self):
        enemy_hero = Hero('enemy', 5, 0, 50)
        with self.assertRaises(ValueError) as error:
            self.hero.battle(enemy_hero)
        self.assertEqual(f"You cannot fight enemy. He needs to rest", str(error.exception))

    def test_battle_raises_if_enemy_health_is_negative(self):
        enemy_hero = Hero('enemy', 5, -50, 50)
        with self.assertRaises(ValueError) as error:
            self.hero.battle(enemy_hero)
        self.assertEqual(f"You cannot fight enemy. He needs to rest", str(error.exception))

    def test_battle_draw_conditions(self):
        enemy_hero = Hero('enemy', 5, 100, 50)
        self.hero.damage = 50
        self.assertEqual('Draw', self.hero.battle(enemy_hero))
        self.assertEqual(-150, self.hero.health)
        self.assertEqual(-150, enemy_hero.health)

    def test_battle_win_conditions(self):
        enemy_hero = Hero('enemy', 1, 100, 50)
        self.assertEqual("You win", self.hero.battle(enemy_hero))
        self.assertEqual(-150, enemy_hero.health)
        self.assertEqual(6, self.hero.level)
        self.assertEqual(55, self.hero.damage)
        self.assertEqual(55, self.hero.health)

    def test_battle_lose_conditions(self):
        self.hero.level = 1  # hero('Gosho', 1, 100, 50)
        enemy_hero = Hero('enemy', 5, 100, 50)
        self.assertEqual("You lose", self.hero.battle(enemy_hero))
        self.assertEqual(6, enemy_hero.level)
        self.assertEqual(55, enemy_hero.damage)
        self.assertEqual(55, enemy_hero.health)


if __name__ == '__main__':
    main()
