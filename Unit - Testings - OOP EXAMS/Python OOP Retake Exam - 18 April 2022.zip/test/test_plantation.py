from project.plantation import Plantation

from unittest import TestCase, main


class PlantationTests(TestCase):
    def test_init(self):
        self.garden = Plantation(10)
        self.assertEqual(10, self.garden.size)
        self.assertEqual({}, self.garden.plants)
        self.assertEqual([], self.garden.workers)

    def test_raises_if_size_negative(self):
        self.garden = Plantation(5)
        with self.assertRaises(ValueError) as error:
            self.garden.size = -1
        self.assertEqual("Size must be positive number!", str(error.exception))


    def test_if_worker_is_already_hired(self):
        self.garden = Plantation(10)
        self.garden.hire_worker('Gosho')
        with self.assertRaises(ValueError) as error:
            self.garden.hire_worker('Gosho')
        self.assertEqual("Worker already hired!", str(error.exception))

    def test_hire_worker_returns_proper_string_when_successfully_added(self):
        self.garden = Plantation(10)
        result = self.garden.hire_worker('Gosho')
        self.assertEqual(len(self.garden.workers), 1)
        self.assertEqual(f"Gosho successfully hired.", result)

    def test_len_method(self):
        self.garden = Plantation(10)
        self.garden.hire_worker('Gosho')
        self.assertEqual(0, self.garden.__len__())
        self.garden.planting('Gosho', 'plant1')
        self.garden.planting('Gosho', 'plant2')
        self.assertEqual(2, self.garden.__len__())


    def test_len_method1(self):
        self.garden = Plantation(5)
        self.garden.hire_worker('Gosho')
        self.garden.hire_worker('Pesho')
        self.garden.plants['Gosho'] = ['plant1']
        self.garden.plants['Pesho'] = ['plant2']
        self.assertEqual(2,self.garden.__len__())

    def test_planting_raises_when_worker_not_in_workers_list_names(self):
        self.garden = Plantation(10)
        with self.assertRaises(ValueError) as error:
            self.garden.planting('Pesho', 'plant1')
        self.assertEqual(f"Worker with name Pesho is not hired!", str(error.exception))

    def test_planting_raises_when_plantation_is_full(self):
        self.garden = Plantation(1)
        self.garden.hire_worker('Gosho')
        self.garden.planting('Gosho', 'plant1')
        with self.assertRaises(ValueError) as error:
            self.garden.planting('Gosho', 'plant2')
        self.assertEqual("The plantation is full!", str(error.exception))

    def test_planting_worker_is_correct_and_make_first_planting_returns_proper_string(self):
        self.garden = Plantation(5)
        self.garden.hire_worker('Gosho')
        self.assertEqual(f"Gosho planted it's first plant1.", self.garden.planting('Gosho', 'plant1'))

    def test_planting_worker_is_correct_and_make_second_or_more_plantings_returns_proper_string(self):
        self.garden = Plantation(5)
        self.garden.hire_worker('Gosho')
        self.garden.planting('Gosho', 'plant1')
        self.assertEqual(len(self.garden.plants['Gosho']), 1)
        self.assertEqual(f"Gosho planted plant2.", self.garden.planting('Gosho', 'plant2'))

    def test_str_wrong_output(self):
        self.assertEqual(Plantation(2).__str__().strip(), 'Plantation size: 2')
        self.pl = Plantation(2)
        self.pl.hire_worker('Martin')
        self.pl.planting('Martin', 'Radishes')
        self.assertEqual(self.pl.__str__().strip(), 'Plantation size: 2\nMartin\nMartin planted: Radishes')

    def test_repr_wrong_output(self):
        self.assertEqual(Plantation(2).__repr__().strip(), 'Size: 2\nWorkers:')
        self.pl = Plantation(2)
        self.pl.hire_worker('Martin')
        self.pl.planting('Martin', 'Radishes')
        self.assertEqual(self.pl.__repr__().strip(), 'Size: 2\nWorkers: Martin')

if __name__ == '__main__':
    main()
