from project.team import Team
from unittest import TestCase, main


class TeamTests(TestCase):
    NAME = "RED"

    def setUp(self) -> None:
        self.team = Team(self.NAME)

    def test_init(self):
        self.assertEqual('RED', self.team.name)
        self.assertEqual({}, self.team.members)

    def test_wrong_name_raises(self):
        with self.assertRaises(ValueError) as error:
            new_team = Team('team123')
        self.assertEqual("Team Name can contain only letters!", str(error.exception))

    def test_add_member(self):
        member_to_add = {'gogo': 25}
        result = self.team.add_member(**member_to_add)
        self.assertEqual(f"Successfully added: gogo", result)
        self.assertTrue('gogo' in self.team.members.keys())
        self.assertEqual(25, self.team.members['gogo'])

    def test_remove_member_if_member_not_exist(self):
        member_to_add = {'gogo': 25}
        self.team.add_member(**member_to_add)
        result = self.team.remove_member('pesho')
        self.assertEqual(f"Member with name pesho does not exist", result)
        self.assertFalse('pesho' in self.team.members)

    def test_remove_successfully(self):
        member_to_add = {'gogo': 25, 'pesho': 20}
        self.team.add_member(**member_to_add)
        result = self.team.remove_member('gogo')
        self.assertEqual(f"Member gogo removed", result)
        self.assertFalse('gogo' in self.team.members)

    def test_gt_(self):
        other_team = Team('BLUE')
        member_to_add1 = {'stoqn': 23}
        other_team.add_member(**member_to_add1)

        member_to_add2 = {'gogo': 25, 'pesho': 20}
        self.team.add_member(**member_to_add2)

        result1 = self.team > other_team  # True
        result2 = other_team > self.team  # False

        # self.assertTrue(result1)  # WRONG !
        # self.assertFalse(result2)  # WRONG !

        self.assertEqual(True, result1)
        self.assertEqual(False, result2)

    def test_len_(self):
        self.assertEqual(0, self.team.__len__())
        member_to_add = {'gogo': 25, 'pesho': 20}
        self.team.add_member(**member_to_add)
        self.assertEqual(2, self.team.__len__())
        self.assertTrue('gogo' in self.team.members)
        self.assertTrue('pesho' in self.team.members)
        self.assertEqual({'gogo': 25, 'pesho': 20}, self.team.members)

    def test__add__(self):
        member_to_add2 = {'gogo': 25}
        self.team.add_member(**member_to_add2)

        other_team = Team('BLUE')
        member_to_add1 = {'stoqn': 23}
        other_team.add_member(**member_to_add1)

        merged_team = self.team + other_team
        self.assertEqual('REDBLUE', merged_team.name)
        self.assertEqual({'gogo': 25, 'stoqn': 23}, merged_team.members)

    def test__str__(self):
        member_to_add = {'gogo': 25, 'pesho': 20}
        self.team.add_member(**member_to_add)

        result = [f"Team name: RED", f"Member: gogo - 25-years old", f"Member: pesho - 20-years old"]
        self.assertEqual('\n'.join(result), self.team.__str__())


if __name__ == '__main__':
    main()
