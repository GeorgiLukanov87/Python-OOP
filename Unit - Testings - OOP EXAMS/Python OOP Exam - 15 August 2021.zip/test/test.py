from project.pet_shop import PetShop
from unittest import TestCase, main


class PetShopTests(TestCase):
    NAME = 'shop'

    def setUp(self) -> None:
        self.shop = PetShop(self.NAME)

    def test_init(self):
        self.assertEqual('shop', self.shop.name)
        self.assertEqual({}, self.shop.food)
        self.assertEqual([], self.shop.pets)

    def test_add_food_raises_qty_0(self):
        with self.assertRaises(ValueError) as error:
            self.shop.add_food('dog_food', 0)
        self.assertEqual("Quantity cannot be equal to or less than 0", str(error.exception))

    def test_add_food_raises_if_qty_negative_number(self):
        with self.assertRaises(ValueError) as error:
            self.shop.add_food('dog_food', -10)
        self.assertEqual("Quantity cannot be equal to or less than 0", str(error.exception))

    def test_add_food_if_food_name_not_in_food_return_proper_string_when_added_successfully(self):
        food1 = 'dog food'
        self.assertFalse(food1 in self.shop.food)
        self.assertEqual(f"Successfully added 10.00 grams of dog food.",
                         self.shop.add_food(food1, 10))
        self.assertEqual(10, self.shop.food[food1])

    def test_add_food_if_food_name_already_exist_return_proper_string_when_added_successfully(self):
        food1 = 'cat food'
        qty = 20
        self.shop.food = {food1: qty}
        self.assertTrue(food1 in self.shop.food)
        self.assertEqual(f"Successfully added 20.00 grams of cat food.",
                         self.shop.add_food(food1, qty))

    def test_add_pet_raises_when_pet_name_already_exist(self):
        pet1 = 'dog'
        self.shop.pets = [pet1]
        with self.assertRaises(Exception) as ex:
            self.shop.add_pet(pet1)
        self.assertEqual("Cannot add a pet with the same name", str(ex.exception))
        self.assertEqual([pet1], self.shop.pets)

    def test_add_pet_returns_proper_string_if_add_is_successfully(self):
        pet1 = 'dog'
        pet2 = 'cat'
        self.assertEqual(f"Successfully added dog.", self.shop.add_pet(pet1))
        self.assertEqual([pet1], self.shop.pets)

        self.assertEqual(f"Successfully added cat.", self.shop.add_pet(pet2))
        self.assertEqual([pet1, pet2], self.shop.pets)

    def test_feed_pet_raises_if_pet_name_not_exist(self):
        food1 = 'dog food'
        name1 = 'gosho'
        name2 = 'pesho'
        self.shop.pets = [name2]

        with self.assertRaises(Exception) as ex:
            self.shop.feed_pet(food1, name1)
        self.assertEqual(f"Please insert a valid pet name", str(ex.exception))
        self.assertFalse(name1 in self.shop.pets)
        self.assertEqual([name2], self.shop.pets)

    def test_feed_pet_if_food_name_not_exist_return_proper_string(self):
        food1 = 'dog food'
        food2 = 'cat food'
        qty1 = 10
        pet_name1 = 'gosho'
        self.shop.pets = [pet_name1]
        self.shop.food = {food1: qty1}
        self.assertEqual(f'You do not have cat food', self.shop.feed_pet(food2, pet_name1))
        self.assertFalse(food2 in self.shop.food)
        self.assertEqual({food1: qty1}, self.shop.food)

    def test_feed_pet_if_qty_is_lower_than_100_return_proper_string(self):
        food1 = 'dog food'
        qty1 = 99
        pet_name1 = 'gosho'
        self.shop.pets = [pet_name1]
        self.shop.food = {food1: qty1}
        self.assertEqual("Adding food...", self.shop.feed_pet(food1, pet_name1))
        self.assertEqual(1099.00, self.shop.food[food1])

    def test_feed_pet_successfully_return_proper_string(self):
        food1 = 'dog food'
        qty1 = 150
        pet_name1 = 'gosho'
        self.shop.pets = [pet_name1]
        self.shop.food = {food1: qty1}
        self.assertEqual(f"gosho was successfully fed", self.shop.feed_pet(food1, pet_name1))
        self.assertEqual(50, self.shop.food[food1])

    def test_repr(self):
        pet_name1 = 'gosho'
        pet_name2 = 'pesho'
        self.shop.pets = [pet_name1, pet_name2]

        result = f'Shop shop:\nPets: gosho, pesho'
        self.assertEqual(result, self.shop.__repr__())


if __name__ == '__main__':
    main()
