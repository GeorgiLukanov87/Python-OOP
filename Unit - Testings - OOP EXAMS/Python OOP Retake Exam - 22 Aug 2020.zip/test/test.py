from project.student_report_card import StudentReportCard
from unittest import TestCase, main


class StudentReportCardTests(TestCase):
    STUDENT_NAME = 'Gosho'
    SCHOOL_YEAR = 6

    def setUp(self) -> None:
        self.card = StudentReportCard(self.STUDENT_NAME, self.SCHOOL_YEAR)

    def test_init(self):
        self.assertEqual('Gosho', self.card.student_name)
        self.assertEqual(6, self.card.school_year)
        self.assertEqual({}, self.card.grades_by_subject)

    def test_init_edge_case_year_1(self):
        new_student = StudentReportCard('student1', 1)
        self.assertEqual('student1', new_student.student_name)
        self.assertEqual(1, new_student.school_year)
        self.assertEqual({}, new_student.grades_by_subject)

    def test_init_edge_case_year_12(self):
        new_student = StudentReportCard('student2', 12)
        self.assertEqual('student2', new_student.student_name)
        self.assertEqual(12, new_student.school_year)
        self.assertEqual({}, new_student.grades_by_subject)

    def test_wrong_student_name_raises(self):
        with self.assertRaises(ValueError) as error:
            self.card.student_name = ''
        self.assertEqual("Student Name cannot be an empty string!", str(error.exception))

    def test_wrong_school_year_more_than_12_raises(self):
        with self.assertRaises(ValueError) as error:
            self.card.school_year = 15
        self.assertEqual("School Year must be between 1 and 12!", str(error.exception))

    def test_wrong_school_year_is_zero_raises(self):
        with self.assertRaises(ValueError) as error:
            self.card.school_year = 0
        self.assertEqual("School Year must be between 1 and 12!", str(error.exception))

    def test_wrong_school_year_is_negative_raises(self):
        with self.assertRaises(ValueError) as error:
            self.card.school_year = -5
        self.assertEqual("School Year must be between 1 and 12!", str(error.exception))

    def test_add_grade_without_subject(self):
        subject = 'math'
        grade = 5

        self.card.add_grade(subject, grade)
        self.assertEqual([grade], self.card.grades_by_subject[subject])
        self.assertTrue(subject in self.card.grades_by_subject)

    def test_add_grade_if_subject_exist(self):
        subject = 'math'
        grade1 = 5.50
        grade2 = 4.50
        self.card.add_grade(subject, grade1)
        self.assertEqual(1, self.card.grades_by_subject[subject].__len__())
        self.card.add_grade(subject, grade2)

        self.assertEqual([grade1, grade2], self.card.grades_by_subject[subject])
        self.assertTrue(grade1 in self.card.grades_by_subject[subject])
        self.assertTrue(grade2 in self.card.grades_by_subject[subject])
        self.assertEqual(2, self.card.grades_by_subject[subject].__len__())

    def test_average_grade_return_proper_print_string(self):
        self.card.grades_by_subject = {'math': [5, 5], 'info': [5, 5]}
        average_grade1 = (5 + 5) / 2
        average_grade2 = (5 + 5) / 2
        result = [f"math: {average_grade1:.2f}", f"info: {average_grade2:.2f}"]
        self.assertEqual('\n'.join(result), self.card.average_grade_by_subject())

    def test_average_grade_for_all_subject_return_proper_print_string(self):
        self.card.grades_by_subject = {'math': [5, 5], 'info': [5, 5]}
        final_result = f"Average Grade: 5.00"
        self.assertEqual(final_result, self.card.average_grade_for_all_subjects())

    def test_repr(self):
        self.card.grades_by_subject = {'math': [5, 5], 'info': [5, 5]}
        result = f"Name: Gosho\n" \
                 f"Year: 6\n" \
                 f"----------\n" \
                 f"math: 5.00\n" \
                 f"info: 5.00\n" \
                 f"----------\n" \
                 f"Average Grade: 5.00"
        self.assertEqual(result, self.card.__repr__())


if __name__ == '__main__':
    main()
