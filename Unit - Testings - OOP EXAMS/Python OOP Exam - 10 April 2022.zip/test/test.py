from project.movie import Movie
from unittest import TestCase, main


class MovieTests(TestCase):
    NAME = 'GOT'
    YEAR = 2000
    RATING = 10

    def setUp(self) -> None:
        self.movie = Movie(self.NAME, self.YEAR, self.RATING)

    def test_init(self):
        self.assertEqual('GOT', self.movie.name)
        self.assertEqual(2000, self.movie.year)
        self.assertEqual(10, self.movie.rating)
        self.assertEqual([], self.movie.actors)
        self.assertEqual(0, len(self.movie.actors))

    def test_wrong_name_validation_raises(self):
        with self.assertRaises(ValueError) as error:
            self.movie.name = ""
        self.assertEqual(str(error.exception), "Name cannot be an empty string!")

    def test_wrong_year_validation_raises(self):
        with self.assertRaises(ValueError) as error:
            self.movie.year = 1886
        self.assertEqual(str(error.exception), "Year is not valid!")

    def test_add_actor_when_actor_already_in_return_string(self):
        self.movie.actors = ['Neo']
        self.assertEqual(self.movie.add_actor('Neo'), f"Neo is already added in the list of actors!")

    def test_add_actor_when_actor_not_exist_(self):
        self.assertEqual(len(self.movie.actors), 0)
        self.movie.add_actor('Neo')
        self.assertEqual(len(self.movie.actors), 1)
        self.assertEqual(self.movie.actors, ['Neo'])

        self.movie.add_actor('Trinity')
        self.assertEqual(len(self.movie.actors), 2)
        self.assertEqual(self.movie.actors, ['Neo', 'Trinity'])

    def test_gt_method(self):
        self.another_movie = Movie('HOTD', 2020, 8)
        result1 = self.movie > self.another_movie
        result2 = self.another_movie > self.movie

        self.assertEqual(result1, f'"{self.movie.name}" is better than "{self.another_movie.name}"')
        self.assertEqual(result2, f'"{self.movie.name}" is better than "{self.another_movie.name}"')

    def test_repr_method(self):
        self.movie.add_actor('Neo')
        result = []
        result.append(f"Name: GOT")
        result.append(f"Year of Release: 2000")
        result.append(f"Rating: 10.00")
        result.append(f"Cast: Neo")

        self.assertEqual(self.movie.__repr__(), '\n'.join(result))


if __name__ == "__main__":
    main()
