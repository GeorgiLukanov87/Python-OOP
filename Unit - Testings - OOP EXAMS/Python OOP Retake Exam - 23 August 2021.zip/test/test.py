from project.library import Library
from unittest import TestCase, main


class LibraryTests(TestCase):
    NAME = 'NAME'

    def setUp(self) -> None:
        self.library = Library(self.NAME)

    def test_init(self):
        self.assertEqual('NAME', self.library.name)
        self.assertEqual({}, self.library.readers)
        self.assertEqual({}, self.library.books_by_authors)

    def test_wrong_name_raises(self):
        with self.assertRaises(ValueError) as error:
            new_lib = Library('')
        self.assertEqual("Name cannot be empty string!", str(error.exception))

    def test_add_book_if_author_not_exist(self):
        author = 'author1'
        title = 'title1'
        self.library.add_book(author, title)
        self.assertEqual({author: [title]}, self.library.books_by_authors)
        self.assertEqual([title], self.library.books_by_authors[author])

    def test_add_book_if_author_exist_but_add_new_title(self):
        author = 'author'
        title = 'title'
        new_title = 'new title'
        self.library.add_book(author, title)
        self.library.add_book(author, new_title)
        self.assertTrue(new_title in self.library.books_by_authors[author])

    def test_add_reader_if_reader_already_exist(self):
        self.library.readers = {'gogo': []}
        result = self.library.add_reader('gogo')
        self.assertEqual(f"gogo is already registered in the NAME library.", result)
        self.assertTrue('gogo' in self.library.readers)

    def test_add_reader_if_reader_not_exist(self):
        self.library.add_reader('gogo')
        self.assertTrue("gogo" in self.library.readers.keys())
        self.assertEqual([], self.library.readers['gogo'])

    def test_rent_book_if_reader_not_registered(self):
        reader_name = 'gogo'
        book_author = 'author'
        book_title = 'title'
        result = self.library.rent_book(reader_name, book_author, book_title)
        self.assertEqual(f"gogo is not registered in the NAME Library.", result)
        self.assertFalse(reader_name in self.library.readers.keys())

    def test_rent_book_if_library_not_have_any_of_this_authors_books(self):
        reader_name = 'gogo'
        book_author = 'author'
        book_title = 'title'
        self.library.add_reader(reader_name)
        result = self.library.rent_book(reader_name, book_author, book_title)
        self.assertEqual(f"NAME Library does not have any author's books.", result)
        self.assertFalse(book_author in self.library.books_by_authors.keys())

    def test_rent_book_if_book_title_not_in_authors_books(self):
        reader_name = 'gogo'
        book_author = 'author'
        book_title = 'title'
        self.library.add_reader(reader_name)
        self.library.add_book(book_author, book_title)

        new_title = 'new title'
        result = self.library.rent_book(reader_name, book_author, new_title)
        self.assertEqual(f"""NAME Library does not have author's "new title".""", result)
        self.assertFalse(new_title in self.library.books_by_authors[book_author])

    def test_rent_book_successfully(self):
        reader_name = 'gogo'
        book_author = 'author'
        book_title1 = 'title1'
        book_title2 = 'title2'
        self.library.add_reader(reader_name)
        self.library.add_book(book_author, book_title1)
        self.library.add_book(book_author, book_title2)

        self.library.rent_book(reader_name, book_author, book_title2)
        self.assertFalse(book_title2 in self.library.books_by_authors[book_author])
        self.assertEqual([{'author': 'title2'}], self.library.readers[reader_name])


if __name__ == '__main__':
    main()
