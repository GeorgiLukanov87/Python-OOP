from unittest import TestCase, main

from project.train.train import Train


class TrainTests(TestCase):
    TRAIN_FULL = "Train is full"
    PASSENGER_EXISTS = "Passenger {} Exists"
    PASSENGER_NOT_FOUND = "Passenger Not Found"
    PASSENGER_ADD = "Added passenger {}"
    PASSENGER_REMOVED = "Removed {}"
    ZERO_CAPACITY = 0

    def setUp(self) -> None:
        self.train = Train('train', 10)

    def test_init(self):
        self.assertEqual('train', self.train.name)
        self.assertEqual(10, self.train.capacity)
        self.assertEqual([], self.train.passengers)

    def test_add_raises_if_train_full(self):
        self.train.capacity = 1
        self.train.passengers = ['Gogo']
        with self.assertRaises(ValueError) as error:
            self.train.add('John')
        self.assertEqual(self.TRAIN_FULL, str(error.exception))
        self.assertEqual(1, self.train.passengers.__len__())
        self.assertEqual(['Gogo'], self.train.passengers)

    def test_add_raises_if_passenger_exist(self):
        self.train.capacity = 5
        self.train.passengers = ['Gogo', 'Pesho']
        with self.assertRaises(ValueError) as error:
            self.train.add('Gogo')
        self.assertEqual("Passenger Gogo Exists", str(error.exception))
        self.assertTrue('Gogo' in self.train.passengers)
        self.assertEqual(['Gogo', 'Pesho'], self.train.passengers)
        self.assertEqual(2, self.train.passengers.__len__())

    def test_add_when_added_successfully_return_proper_string(self):
        self.train.capacity = 5
        self.train.passengers = ['Gogo', 'Pesho']
        self.assertEqual("Added passenger Jivko", self.train.add('Jivko'))
        self.assertTrue('Jivko' in self.train.passengers)
        self.assertEqual(['Gogo', 'Pesho', 'Jivko'], self.train.passengers)
        self.assertEqual(3, self.train.passengers.__len__())

    def test_remove_passenger_raises_if_passanger_name_not_exist(self):
        self.train.passengers = ['Go', 'Sho']
        name1 = 'Pesho'
        with self.assertRaises(ValueError) as error:
            self.train.remove(name1)
        self.assertEqual("Passenger Not Found", str(error.exception))
        self.assertFalse(name1 in self.train.passengers)
        self.assertEqual(['Go', 'Sho'], self.train.passengers)
        self.assertEqual(2, self.train.passengers.__len__())

    def test_remove_successfully_removed_return_proper_string(self):
        self.train.passengers = ['Go', 'Sho']
        name1 = 'Go'
        self.assertEqual("Removed Go", self.train.remove(name1))
        self.assertFalse(name1 in self.train.passengers)
        self.assertEqual(['Sho'], self.train.passengers)
        self.assertEqual(1, self.train.passengers.__len__())


if __name__ == '__main__':
    main()
