from project.animals.animal import Mammal


class Mouse(Mammal):
    @property
    def allowed_foods(self):
        return ['Vegetable', 'Fruit']

    @property
    def weight_incremental(self):
        return 0.1

    def make_sound(self):
        return 'Squeak'

    def __init__(self, name, weight, living_region):
        super().__init__(name, weight, living_region)


class Dog(Mammal):
    @property
    def allowed_foods(self):
        return ['Meat']

    @property
    def weight_incremental(self):
        return 0.4

    def make_sound(self):
        return 'Woof!'

    def __init__(self, name, weight, living_region):
        super().__init__(name, weight, living_region)


class Cat(Mammal):
    @property
    def allowed_foods(self):
        return ['Vegetable', 'Meat']

    @property
    def weight_incremental(self):
        return 0.3

    def make_sound(self):
        return 'Meow'

    def __init__(self, name, weight, living_region):
        super().__init__(name, weight, living_region)


class Tiger(Mammal):
    @property
    def allowed_foods(self):
        return ['Meat']

    @property
    def weight_incremental(self):
        return 1

    def make_sound(self):
        return "ROAR!!!"

    def __init__(self, name, weight, living_region):
        super().__init__(name, weight, living_region)
